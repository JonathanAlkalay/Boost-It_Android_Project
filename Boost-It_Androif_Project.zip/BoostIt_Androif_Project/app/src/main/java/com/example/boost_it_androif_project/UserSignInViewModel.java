package com.example.boost_it_androif_project;

import androidx.lifecycle.ViewModel;

public class UserSignInViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}