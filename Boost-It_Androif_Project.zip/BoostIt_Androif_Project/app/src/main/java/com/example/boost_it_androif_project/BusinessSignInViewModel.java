package com.example.boost_it_androif_project;

import androidx.lifecycle.ViewModel;

public class BusinessSignInViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}